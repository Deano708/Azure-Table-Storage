﻿using Microsoft.AspNetCore.Mvc;
using CLDV6212_ICE2_ST10449407.Models;
using CLDV6212_ICE2_ST10449407.Services;

namespace CLDV6212_ICE2_ST10449407.Controllers
{
    public class ProductController : Controller
    {
        private readonly TableStorageService _tableStorageService;

        public ProductController(TableStorageService tableStorageService)
        {
            _tableStorageService = tableStorageService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _tableStorageService.GetAllProductsAsync();
            return View(products);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            if (!ModelState.IsValid) return View(product);
            await _tableStorageService.AddProductAsync(product);

            return RedirectToAction(nameof(Index));
        }

    }
}
