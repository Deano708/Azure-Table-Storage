using CLDV6212_ICE2_ST10449407.Services;

var builder = WebApplication.CreateBuilder(args);

// Add controllers + views
builder.Services.AddControllersWithViews();

// Get values from configuration
var connectionString = builder.Configuration.GetConnectionString("TableStorage");
var tableName = builder.Configuration["TableName"];

// Register the TableStorageService as a singleton
builder.Services.AddSingleton(sp =>
    new TableStorageService(connectionString, tableName));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
