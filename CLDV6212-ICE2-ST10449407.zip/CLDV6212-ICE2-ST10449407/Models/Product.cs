﻿
using Azure;
using Azure.Data.Tables;
using System;

namespace CLDV6212_ICE2_ST10449407.Models
{
    public class Product : ITableEntity
    {
        public string RowKey { get; set; }
        public string PartitionKey { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public bool Clearance { get; set; }

        public ETag ETag { get; set; } = ETag.All;
        public DateTimeOffset? Timestamp { get; set; }
    }
}
